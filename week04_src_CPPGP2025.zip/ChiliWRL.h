﻿#pragma once
#pragma warning(disable:4265)
#include <wrl.h>
#pragma warning(default:4265)