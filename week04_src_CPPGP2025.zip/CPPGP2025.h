﻿#pragma once

class GameState;
void ChangeState(GameState* newState);